"""Exploratory Data Analysis of Student Performance.

Uses synthetic data by default. To use your own CSV (e.g. UCI student-mat.csv),
uncomment the read_csv line and adjust the column names below.
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # remove this line if you want plots to pop up
import matplotlib.pyplot as plt
import seaborn as sns

os.makedirs("images", exist_ok=True)

# 1. Load data ---------------------------------------------------------------
# df = pd.read_csv("student-mat.csv", sep=";")
np.random.seed(42)
n = 200
study = np.random.normal(5, 2, n).clip(0, 12)
attend = np.random.normal(80, 10, n).clip(40, 100)
math = (35 + 4 * study + 0.2 * attend + np.random.normal(0, 6, n)).clip(0, 100)
reading = (0.7 * math + 20 + np.random.normal(0, 6, n)).clip(0, 100)
df = pd.DataFrame({"study_hours": study, "attendance": attend,
                   "math_score": math, "reading_score": reading})
df.loc[[10, 50], "math_score"] = [2, 99]  # inject outliers

# 2. Inspect -----------------------------------------------------------------
print("Shape:", df.shape)
df.info()
print("\nMissing values:\n", df.isnull().sum())

# 3. Descriptive statistics --------------------------------------------------
print("\n", df.describe().round(2))
print("\nMedian:\n", df.median().round(2))
print("\nMode:\n", df.mode().iloc[0].round(2))
print("\nVariance:\n", df.var().round(2))

# 4. Distribution of grades --------------------------------------------------
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
sns.histplot(df["math_score"], bins=15, kde=True, ax=ax[0])
ax[0].set_title("Histogram of Math Scores")
sns.boxplot(data=df[["math_score", "reading_score"]], ax=ax[1])
ax[1].set_title("Box Plot of Scores")
plt.tight_layout()
plt.savefig("images/distribution.png", dpi=150)
plt.close()


# Standalone histogram of math scores
sns.histplot(df["math_score"], bins=15, kde=True)
plt.title("Histogram of Math Scores")
plt.xlabel("Math Score"); plt.ylabel("Number of Students")
plt.tight_layout()
plt.savefig("images/histogram.png", dpi=150)
plt.close()

# 5. Relationships -----------------------------------------------------------
sns.scatterplot(data=df, x="study_hours", y="math_score")
plt.title("Study Hours vs Math Score")
plt.savefig("images/scatter.png", dpi=150)
plt.close()

sns.pairplot(df)
plt.savefig("images/pairplot.png", dpi=120)
plt.close()

corr = df.corr()
print("\nCorrelation matrix:\n", corr.round(2))
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Matrix")
plt.tight_layout()
plt.savefig("images/heatmap.png", dpi=150)
plt.close()

# 6. Outlier detection -------------------------------------------------------
def iqr_outliers(s):
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr = q3 - q1
    return s[(s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)]

print("\nIQR outliers (math):\n", iqr_outliers(df["math_score"]).round(2))

z = (df["math_score"] - df["math_score"].mean()) / df["math_score"].std()
print("\nZ-score outliers (|z|>3):\n", df[abs(z) > 3].round(2))

# 7. Impact of outliers ------------------------------------------------------
clean = df[~df.index.isin(iqr_outliers(df["math_score"]).index)]
print("\nMean with outliers   :", round(df["math_score"].mean(), 2))
print("Mean without outliers:", round(clean["math_score"].mean(), 2))
print("Std with outliers    :", round(df["math_score"].std(), 2))
print("Std without outliers :", round(clean["math_score"].std(), 2))
print("Corr(study, math) with/without:",
      round(df["study_hours"].corr(df["math_score"]), 3),
      round(clean["study_hours"].corr(clean["math_score"]), 3))
