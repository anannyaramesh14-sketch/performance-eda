# Exploratory Data Analysis of Student Performance

## Aim
To perform exploratory data analysis on student performance data by computing descriptive statistics, visualizing grade distributions, studying relationships between variables, and identifying outliers.

## Apparatus
- Python 3 (Jupyter Notebook / Google Colab)
- Libraries: pandas, numpy, matplotlib, seaborn
- Dataset: synthetic data of 200 students (study hours, attendance, math score, reading score). Can be replaced with the UCI `student-mat.csv`.

## Methodology
1. Import libraries and load the dataset.
2. Inspect the data (shape, types, missing values).
3. Compute mean, median, mode, standard deviation, min, max and quartiles.
4. Plot histograms and box plots of the scores.
5. Draw scatter plots and a correlation heatmap to study relationships.
6. Detect outliers using the IQR rule (below Q1 − 1.5·IQR or above Q3 + 1.5·IQR) and the Z-score (|z| > 3).
7. Interpret the results and discuss the impact of outliers.
8. Build a Pass/Fail classifier (logistic regression) and evaluate it with accuracy, precision, recall, specificity and F1 score, then test the effect of noise.

## Program
- [`eda_student_performance.py`](eda_student_performance.py): descriptive statistics, plots, correlation, outliers
- [`classification_metrics.py`](classification_metrics.py): classification metrics and noise test

```bash
pip install -r requirements.txt
python eda_student_performance.py
python classification_metrics.py
```
Plots are saved to the `images/` folder.

## Result

### Descriptive statistics
| Variable | Mean | Median | Std Dev | Min | Max |
|---|---|---|---|---|---|
| study_hours | 4.92 | 4.99 | 1.86 | 0.00 | 10.44 |
| attendance | 80.71 | 80.79 | 9.48 | 47.59 | 100.00 |
| math_score | 70.09 | 69.70 | 10.57 | 2.00 | 99.09 |
| reading_score | 69.27 | 69.35 | 9.29 | 46.44 | 95.06 |

Mean and median are very close for every variable, so the distributions are roughly symmetric. No missing values were found.

### Distribution of grades
![Histogram](images/histogram.png)
![Distribution](images/distribution.png)

The math score histogram is approximately bell-shaped, centred near 70. The box plot shows the median, the interquartile range, and points beyond the whiskers.

### Relationships between variables
![Scatter](images/scatter.png)
![Heatmap](images/heatmap.png)

| Pair | Correlation |
|---|---|
| study_hours vs math_score | 0.67 |
| math_score vs reading_score | 0.65 |
| study_hours vs reading_score | 0.56 |
| attendance vs math_score | 0.18 |

Study hours has a strong positive relationship with math score, math and reading scores move together, and attendance has only a weak relationship in this data.

### Histogram vs Scatter Plot

| Aspect | Histogram | Scatter Plot |
|---|---|---|
| Variables shown | One variable (math score) | Two variables (study hours vs math score) |
| Purpose | Shows the distribution: shape, centre, spread | Shows the relationship or correlation between variables |
| Axes | X: score bins, Y: number of students | X: study hours, Y: math score |
| Data representation | Values grouped into bins | Each student is an individual point |
| Main finding here | Bell-shaped, centred near 70, roughly symmetric | Clear upward trend (r = 0.67): more study, higher score |
| Outliers | Appear as isolated bars at the extremes (2 and about 99) | Appear as points far from the main cloud |
| Best used for | Checking normality, skewness and spread | Spotting trends, correlation and unusual pairs |
| Limitation | Cannot show how two variables relate; depends on bin width | Cannot show how many values fall in a range |

**Summary:** The histogram tells us *how the scores are distributed*, while the scatter plot tells us *what influences them*. Used together, they give a fuller picture: the histogram confirms the scores are approximately normal, and the scatter plot shows study hours is a strong factor behind them.

### Outliers
- **IQR rule (math):** 4 outliers: scores of 2.00, 99.09, 99.00 and 98.01.
- **Z-score rule (|z| > 3):** 1 outlier: the score of 2.00.

### Impact of outliers
| Measure | With outliers | Without outliers |
|---|---|---|
| Mean (math) | 70.09 | 70.00 |
| Std dev (math) | 10.57 | 8.81 |
| Corr(study, math) | 0.665 | 0.729 |

The mean barely moves, but the standard deviation is inflated by about 20% and the correlation with study hours is weakened. The median and IQR are robust to these points. Outliers should be investigated (data-entry error vs. genuine extreme performance) before being removed, capped or kept.

### Classification metrics (Pass/Fail prediction)
A logistic regression model predicts whether a student passes (math score >= 60) from study hours and attendance (70/30 train-test split, 60 test students; 176 of 200 students pass).

![Confusion Matrix](images/confusion_matrix.png)

| Metric | Value | Meaning |
|---|---|---|
| Accuracy | 0.883 | 88.3% of all predictions were correct |
| Precision | 0.897 | Of students predicted to pass, 89.7% actually passed |
| Recall | 0.981 | Of students who actually passed, 98.1% were found |
| Specificity | 0.143 | Of students who actually failed, only 14.3% were identified |
| F1 score | 0.937 | Harmonic mean of precision and recall |

Confusion matrix: TN = 1, FP = 6, FN = 1, TP = 52.

**Interpretation:** Accuracy, precision, recall and F1 look high, but this is misleading. Only 12% of students fail, so the model mostly predicts "pass" and catches just 1 of 7 failing students (low specificity). On imbalanced data, accuracy alone should not be trusted; for finding at-risk students, class weighting or a lower decision threshold would help.

### Effect of noise
Gaussian noise (a multiple of each feature's standard deviation) was added to the test features and the metrics averaged over 50 runs.

![Noise effect](images/noise_effect.png)

| Noise level | Accuracy | Precision | Recall | Specificity | F1 score |
|---|---|---|---|---|---|
| 0x (clean) | 0.883 | 0.897 | 0.981 | 0.143 | 0.937 |
| 0.25x | 0.896 | 0.908 | 0.982 | 0.249 | 0.944 |
| 0.5x | 0.889 | 0.912 | 0.968 | 0.291 | 0.939 |
| 1.0x | 0.859 | 0.915 | 0.926 | 0.349 | 0.921 |
| 2.0x | 0.771 | 0.910 | 0.822 | 0.386 | 0.863 |

**Interpretation:** Small noise (up to 0.5x) barely changes the results. As noise grows, accuracy falls from 0.883 to 0.771, recall from 0.981 to 0.822, and F1 from 0.937 to 0.863, because the real signal (study hours) is drowned out. Precision stays roughly flat and specificity rises slightly, since noisy inputs make the model predict "pass" less often.

## Conclusion
EDA showed the central tendency, spread and shape of student scores, revealed which factors relate to performance, and identified outliers whose treatment affects later analysis. The classifier's accuracy, precision, recall, specificity and F1 score showed that accuracy can hide poor performance on the minority (fail) class, and the noise test showed that performance degrades as input noise increases.
