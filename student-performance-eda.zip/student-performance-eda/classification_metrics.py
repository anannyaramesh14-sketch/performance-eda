"""Pass/Fail classification of students with evaluation metrics and noise test."""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix, ConfusionMatrixDisplay)

os.makedirs("images", exist_ok=True)

# Same synthetic data as the EDA script
np.random.seed(42)
n = 200
study = np.random.normal(5, 2, n).clip(0, 12)
attend = np.random.normal(80, 10, n).clip(40, 100)
math = (35 + 4 * study + 0.2 * attend + np.random.normal(0, 6, n)).clip(0, 100)
reading = (0.7 * math + 20 + np.random.normal(0, 6, n)).clip(0, 100)
df = pd.DataFrame({"study_hours": study, "attendance": attend,
                   "math_score": math, "reading_score": reading})
df.loc[[10, 50], "math_score"] = [2, 99]

# Target: Pass (1) if math score >= 60, else Fail (0). Predict from study hours + attendance
df["passed"] = (df["math_score"] >= 60).astype(int)
X = df[["study_hours", "attendance"]]
y = df["passed"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

sc = StandardScaler().fit(X_tr)
model = LogisticRegression().fit(sc.transform(X_tr), y_tr)

def evaluate(X_test):
    pred = model.predict(sc.transform(X_test))
    tn, fp, fn, tp = confusion_matrix(y_te, pred).ravel()
    return {"Accuracy": accuracy_score(y_te, pred),
            "Precision": precision_score(y_te, pred),
            "Recall": recall_score(y_te, pred),
            "Specificity": tn / (tn + fp),
            "F1 score": f1_score(y_te, pred)}, pred

print("Class balance (1=pass):", y.value_counts().to_dict())
metrics, pred = evaluate(X_te)
print("\nMetrics on clean test data:")
for k, v in metrics.items():
    print(f"  {k:12s}: {v:.3f}")

cm = confusion_matrix(y_te, pred)
print("\nConfusion matrix [[TN FP],[FN TP]]:\n", cm)
ConfusionMatrixDisplay(cm, display_labels=["Fail", "Pass"]).plot(cmap="Blues")
plt.title("Confusion Matrix")
plt.savefig("images/confusion_matrix.png", dpi=150)
plt.close()

# Noise experiment: add Gaussian noise (multiple of each feature's std) to test features
rng = np.random.default_rng(0)
levels = [0, 0.25, 0.5, 1.0, 2.0]
rows = []
for lv in levels:
    res = []
    for _ in range(50):  # average over 50 noisy copies
        Xn = X_te + rng.normal(0, 1, X_te.shape) * (lv * X_tr.std().values)
        res.append(evaluate(Xn)[0])
    rows.append(pd.DataFrame(res).mean())
noise_df = pd.DataFrame(rows, index=[f"{l}x" for l in levels])
print("\nEffect of noise (avg of 50 runs):\n", noise_df.round(3))

noise_df.plot(marker="o", figsize=(7, 4))
plt.xlabel("Noise level (x feature std)"); plt.ylabel("Score"); plt.ylim(0, 1.05)
plt.title("Effect of Noise on Classification Metrics")
plt.grid(alpha=.3); plt.tight_layout()
plt.savefig("images/noise_effect.png", dpi=150)
plt.close()
